import { View,Text } from "react-native";

export default function Cart(props)
{
  return(
  <View>
    <Text>Cart</Text>
   </View>)
}